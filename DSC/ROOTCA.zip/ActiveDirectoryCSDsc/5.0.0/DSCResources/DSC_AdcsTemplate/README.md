# Description

This resource can be used to add or remove Certificate Authority templates
from an Enterprise CA.
Using this DSC Resource assumes that the `ADCS-Cert-Authority` feature
and the `AdcsCertificationAuthority` resource have been installed with
a `CAType` of `EnterpriseRootCA` or `EnterpriseSubordinateCA`.
